function love.conf(t)

	t.window.width = 800
	t.window.height = 600
	t.title = "LD 32"

end